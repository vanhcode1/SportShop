package com.example.holaorder.Common;

import com.example.holaorder.Model.User;

public class Common {
    public static User currentUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
