package com.example.holaorder.Prevalent;

import com.example.holaorder.Model.User;

public class Prevalent {
    public static User currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";

}
