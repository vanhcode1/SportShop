package com.example.holaorder;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;


import com.example.holaorder.Common.Common;

import com.example.holaorder.Interface.ItemClickListener;
import com.example.holaorder.Model.Category;
import com.example.holaorder.Model.Product;
import com.example.holaorder.ViewHolder.CategoryViewHolder;
import com.example.holaorder.ViewHolder.ProductViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Home extends AppCompatActivity {
    Context context;
    DatabaseReference table_category;
    DatabaseReference table_product;
    TextView textItem;
    ImageView imageUser;
    private List<Product> productList;
    private RecyclerView.Adapter adapter, adapter2;
    private RecyclerView recyclerViewCaregoryList, recyclerViewPopularList;

    private ConstraintLayout btnAllProduct;

    EditText searchHome;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        table_category = database.getReference("Category");
        table_product = database.getReference("Products");

        ((TextView) findViewById(R.id.textHello)).setText("Hello, " + Common.currentUser.getName());
//        Picasso.get().load(Common.currentUser.getImage()).into(imageUser);
        recyclerViewCaregory();
        recyclerViewPopular("");


        btnAllProduct = (ConstraintLayout) findViewById(R.id.allProduct);

        btnAllProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent product = new Intent(Home.this, ListProduct.class);
                startActivity(product);
            }
        });


        searchHome = findViewById(R.id.searchHome);
        searchHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                Intent intent = new Intent(Home.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        DatabaseReference productsRef = database.getReference("Products");

        productsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int count = (int) dataSnapshot.getChildrenCount();
                TextView textView = findViewById(R.id.number_Product);
                textView.setText(count + " Products");
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

//        imageUser.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(Home.this, ProfileActivity.class);
//                startActivity(intent);
//            }
//        });

    }

    private void recyclerViewCaregory() {

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerViewCaregoryList = findViewById(R.id.recyclerView);
        recyclerViewCaregoryList.setLayoutManager(linearLayoutManager);

        FirebaseRecyclerOptions<Category> options =
                new FirebaseRecyclerOptions.Builder<Category>()
                        .setQuery(table_category, Category.class)
                        .build();

        FirebaseRecyclerAdapter<Category, CategoryViewHolder> adapter = new FirebaseRecyclerAdapter<Category, CategoryViewHolder>(options) {
            @NonNull
            @Override
            public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_category, parent, false);
                CategoryViewHolder holder = new CategoryViewHolder(view);
                return holder;
            }

            @Override
            protected void onBindViewHolder(@NonNull CategoryViewHolder categoryViewHolder, int position, @NonNull Category category) {
                categoryViewHolder.tvCategoryName.setText(category.getName());
                Picasso.get().load(category.getImage()).into(categoryViewHolder.imgCategory);
                Category clickItem = category;
                categoryViewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        String selectedCategory = category.getName();
                        recyclerViewPopular(selectedCategory.isEmpty() ? "" : selectedCategory);
                        Toast.makeText(Home.this, clickItem.getName(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        };
        recyclerViewCaregoryList.setAdapter(adapter);
        adapter.startListening();
    }

    private void recyclerViewPopular(String category) {
        Query qrr;
        if (category.isEmpty()) {
            qrr = table_product;
            qrr = qrr.limitToFirst(4).orderByChild("randomField");
        } else {
            qrr = table_product.orderByChild("CategoryId").equalTo(category);
        }


        FirebaseRecyclerOptions<Product> options =
                new FirebaseRecyclerOptions.Builder<Product>()
                        .setQuery(qrr, Product.class)
                        .build();

        GridLayoutManager layoutManagerGrid = new GridLayoutManager(this, 2, GridLayoutManager.HORIZONTAL, false);
        recyclerViewPopularList = findViewById(R.id.recyclerView2);
        recyclerViewPopularList.setLayoutManager(layoutManagerGrid);


        FirebaseRecyclerAdapter<Product, ProductViewHolder> adapter = new FirebaseRecyclerAdapter<Product, ProductViewHolder>(options) {
            @NonNull
            @Override
            public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_popular, parent,false);
                ProductViewHolder holder = new ProductViewHolder(view);
                return holder;
            }

            @Override
            protected void onBindViewHolder(@NonNull ProductViewHolder productViewHolder, int position, @NonNull Product product) {
                String productId = getRef(position).getKey();
                productViewHolder.tvProductName.setText(product.getName());
                Picasso.get().load(product.getImage()).into(productViewHolder.imgProduct);
                productViewHolder.tvPrice.setText(product.getPrice());
                productViewHolder.rate.setRating(Float.parseFloat(product.getRate()));
                Product clickItem = product;

                productViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(Home.this, DetailSport.class);
                        intent.putExtra("ProductId", productId);
                        startActivity(intent);
                    }
                });
                productViewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        Toast.makeText(Home.this, clickItem.getName(), Toast.LENGTH_SHORT).show();
                    }
                });

            }
        };
        recyclerViewPopularList.setAdapter(adapter);
        adapter.startListening();
    }

    public void viewAllProducts(View view) {
        Intent productListIntent = new Intent(Home.this, ListProduct.class);
        startActivity(productListIntent);

    }

}